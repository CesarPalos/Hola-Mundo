﻿Imports System.Data
Imports System
Imports System.Data.OleDb
Imports System.Data.SqlClient
Public Class Producto
    Public Conexion As New SqlClient.SqlConnection("Data Source=CESAR\SQLEXPRESS01; Initial Catalog=componentes; Integrated Security=True")
    Public Cmd As New SqlClient.SqlCommand
    Public Query As String
    Public DS As New DataSet
    Public Adapter As New OleDbDataAdapter
    Public oDataAdapter As SqlDataAdapter
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Conexion As New SqlClient.SqlConnection
        Conexion.ConnectionString = "Data Source=CESAR\SQLEXPRESS01; Initial Catalog=componentes; Integrated Security=True"
        Conexion.Open()
        Dim CmdAgregar As SqlCommand = Conexion.CreateCommand
        CmdAgregar.CommandType = CommandType.StoredProcedure
        CmdAgregar.CommandText = "Agregar_Editar_Producto"
        CmdAgregar.Parameters.Add("@id_producto", SqlDbType.Int).Value = TextBox1.Text
        CmdAgregar.Parameters.Add("@nombre", SqlDbType.VarChar).Value = TextBox2.Text
        CmdAgregar.Parameters.Add("@marca", SqlDbType.VarChar).Value = TextBox3.Text
        CmdAgregar.Parameters.Add("@numero_de_serie", SqlDbType.VarChar).Value = TextBox5.Text
        CmdAgregar.Parameters.Add("@cantidad", SqlDbType.VarChar).Value = TextBox4.Text
        CmdAgregar.Parameters.Add("@precio", SqlDbType.Int).Value = TextBox6.Text
        CmdAgregar.Parameters.Add("@descripcion", SqlDbType.VarChar).Value = TextBox7.Text
        CmdAgregar.ExecuteNonQuery()
        Conexion.Close()
        MsgBox("¡Registro exitoso!")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim Conexion As New SqlClient.SqlConnection
        Conexion.ConnectionString = "Data Source=CESAR\SQLEXPRESS01; Initial Catalog=componentes; Integrated Security=True"
        Conexion.Open()
        Dim CmdEliminar As SqlCommand = Conexion.CreateCommand
        CmdEliminar.CommandType = CommandType.StoredProcedure
        CmdEliminar.CommandText = "Eliminar_Producto"
        CmdEliminar.Parameters.Add("@id_producto", SqlDbType.Int).Value = TextBox1.Text
        CmdEliminar.ExecuteNonQuery()
        Conexion.Close()
        MsgBox("Eliminado Correctamente")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            Conexion.Open()
            Query = String.Format("Select * From producto Where id_producto = '{0}'", TextBox1.Text)
            Dim sqlread As SqlClient.SqlDataReader
            Cmd = New SqlClient.SqlCommand(Query, Conexion)
            Cmd.ExecuteNonQuery()
            sqlread = Cmd.ExecuteReader()

            While sqlread.Read()

                TextBox1.Text = sqlread("id_producto").ToString()
                TextBox2.Text = sqlread("nombre").ToString()
                TextBox3.Text = sqlread("marca").ToString()
                TextBox4.Text = sqlread("numero_de_serie").ToString()
                TextBox5.Text = sqlread("cantidad").ToString()
                TextBox6.Text = sqlread("precio").ToString()
                TextBox7.Text = sqlread("descripcion").ToString()
            End While

            sqlread.Close()
            Conexion.Close()

            MessageBox.Show("Registro Encontrado", "Registro de Empleados", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception : MessageBox.Show("Ah ocurrido un error " + ex.Message)

        End Try
    End Sub
End Class