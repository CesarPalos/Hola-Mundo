﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Clientes
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Conexion As New SqlClient.SqlConnection
        Conexion.ConnectionString = "Data Source=CESAR\SQLEXPRESS01; Initial Catalog=componentes; Integrated Security=True"
        Conexion.Open()
        Dim CmdAgregar As SqlCommand = Conexion.CreateCommand
        CmdAgregar.CommandType = CommandType.StoredProcedure
        CmdAgregar.CommandText = "Agregar_Editar_Cliente"
        CmdAgregar.Parameters.Add("@id_cliente", SqlDbType.Int).Value = TextBox1.Text
        CmdAgregar.Parameters.Add("@nombre", SqlDbType.VarChar).Value = TextBox2.Text
        CmdAgregar.Parameters.Add("@telefono", SqlDbType.VarChar).Value = TextBox3.Text
        CmdAgregar.Parameters.Add("@correo", SqlDbType.VarChar).Value = TextBox4.Text
        CmdAgregar.Parameters.Add("@empleado", SqlDbType.Int).Value = TextBox5.Text
        CmdAgregar.ExecuteNonQuery()
        Conexion.Close()
        MsgBox("¡Registro exitoso!")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim Conexion As New SqlClient.SqlConnection
        Conexion.ConnectionString = "Data Source=CESAR\SQLEXPRESS01; Initial Catalog=componentes; Integrated Security=True"
        Conexion.Open()
        Dim CmdEliminar As SqlCommand = Conexion.CreateCommand
        CmdEliminar.CommandType = CommandType.StoredProcedure
        CmdEliminar.CommandText = "Eliminar_Cliente"
        CmdEliminar.Parameters.Add("@id_cliente", SqlDbType.Int).Value = TextBox1.Text
        CmdEliminar.ExecuteNonQuery()
        Conexion.Close()
        MsgBox("Eliminado Correctamente")
    End Sub
End Class