﻿Imports System
Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SqlClient
Public Class Venta
    Public Conexion As New SqlClient.SqlConnection("Data Source=CESAR\SQLEXPRESS01; Initial Catalog=componentes; Integrated Security=True")
    Public Cmd As New SqlClient.SqlCommand
    Public Query As String
    Public DS As New DataSet
    Public Adapter As New OleDbDataAdapter
    Public oDataAdapter As SqlDataAdapter

    Private Sub Venta_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Cargar_Combobox()
    End Sub

    Public Function LLenar_Combox(Query As String) As DataTable
        Dim DT As New DataTable
        Cmd = New SqlClient.SqlCommand(Query, Conexion)
        Dim DA As New SqlDataAdapter(Cmd)
        DA.Fill(DT)
        Return DT
    End Function

    Private Sub Cargar_Combobox()
        With ComboBox1
            .DataSource = LLenar_Combox("SELECT id_producto, nombre FROM producto")
            .DisplayMember = "nombre"
            .ValueMember = "id_producto"
        End With
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectionChangeCommitted
        Try
            Conexion.Open()
            Query = String.Format("Select * From producto Where id_producto = '{0}'", ComboBox1.SelectedValue)
            Dim sqlread As SqlClient.SqlDataReader
            Cmd = New SqlClient.SqlCommand(Query, Conexion)
            Cmd.ExecuteNonQuery()
            sqlread = Cmd.ExecuteReader()

            While sqlread.Read()

                TextBox1.Text = sqlread("nombre").ToString()
                TextBox2.Text = sqlread("marca").ToString()
                TextBox4.Text = sqlread("numero_de_serie").ToString()
                TextBox5.Text = sqlread("precio").ToString()
                TextBox6.Text = sqlread("descripcion").ToString()

            End While

            sqlread.Close()
            Conexion.Close()

            MessageBox.Show("Registro Encontrado", "Registro de Empleados", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception : MessageBox.Show("Ah ocurrido un error " + ex.Message)

        End Try
    End Sub
End Class