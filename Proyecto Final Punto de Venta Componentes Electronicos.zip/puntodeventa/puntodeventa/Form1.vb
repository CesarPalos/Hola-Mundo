﻿Public Class Form1
    Private Sub ContextMenuStrip1_Opening(sender As Object, e As System.ComponentModel.CancelEventArgs)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub AgregarEmpleadosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AgregarEmpleadosToolStripMenuItem.Click
        Dim aempleado As New Empleado
        aempleado.MdiParent = Me
        aempleado.Show()
    End Sub

    Private Sub AgregarClientesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AgregarClientesToolStripMenuItem.Click
        Dim cliente As New Clientes
        cliente.MdiParent = Me
        cliente.Show()
    End Sub

    Private Sub AgregarProductosToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AgregarProductosToolStripMenuItem.Click
        Dim producto As New Producto
        producto.MdiParent = Me
        producto.Show()
    End Sub

    Private Sub VentaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VentaToolStripMenuItem.Click
        Dim venta As New Venta
        venta.MdiParent = Me
        venta.Show()
    End Sub
End Class
