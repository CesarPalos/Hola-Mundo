create database componentes
use componentes

create table empleado(
id_empleado int primary key not null,
nombre varchar (max),
apellido varchar (max),
telefono varchar (max),
direccion varchar (max),
correo varchar(max),
genero varchar (max),
edad int
)

create table cliente(
id_cliente int primary key not null,
nombre varchar (max),
telefono varchar (max),
correo varchar(max),
empleado int foreign key references empleado (id_empleado)
)

create table producto(
id_producto int primary key not null,
nombre varchar (max),
marca varchar (max),
numero_de_serie varchar (max),
Cantidad int ,
Precio int
)

create table almacen(
id_almacen int primary key not null,
cantidad int,
producto int foreign key references producto (id_producto)
)

create table compra(
id_compra int primary key not null,
cantidad int,
producto varchar (max),
precio int,
detalle_del_producto varchar(max),
empleado int foreign key references empleado (id_empleado),
cliente int foreign key references cliente (id_cliente)
)

create table pago(
id_pago int primary key not null,
compra int foreign key references compra (id_compra)
)

/*Procedimineto*/
Create Procedure Agregar_Empleado
	@id_empleado   Int,
	@nombre        Varchar(Max),
	@apellido      Varchar(Max),
	@direccion     Varchar(Max),
	@telefono      Varchar(Max),
	@correo        Varchar(Max),
	@genero        Varchar(Max),
	@edad          Int


As
Begin
	if not exists(Select * From empleado Where (id_empleado = @id_empleado))
		Begin
			Insert Into empleado Values (@id_empleado, @nombre, @apellido, @direccion, @telefono, @correo, @genero, @edad)
		End
	Else
		Begin
			Update empleado Set id_empleado = @id_empleado, nombre = @nombre, apellido = @apellido, direccion = @direccion, telefono = @telefono, correo = @correo, genero = @genero, edad = @edad Where id_empleado = @id_empleado
		End
End

select * from empleado

Insert Into empleado values('1', 'Admin', '', '', '', '', '', '')


Exec Agregar_Empleado('Admin')